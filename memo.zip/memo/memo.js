$(function() {
   $("#createBtn").click(function() {
      new Memo().create();      
   })
});

function Memo() {
   this.$note = null;
}
// create()
Memo.prototype.create = function() {
   console.log("create");
   var $note = $(
         `<div class="memo-note" id = memo1>
            <div class="memo-bar">
               <span class="glyphicon glyphicon-chevron-up" aria-hidden="true"></span>
               <span class="glyphicon glyphicon-pushpin" aria-hidden="true"></span>
               <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
            </div>
            <div class="memo-edit">
               <textarea class="memo-edit-area"></textarea>
            </div>
         </div>` // 템플릿 문자열
   );
   $note.appendTo($(".memo-area"));
   
   this.$note = $note;
   this.drag();
   
   var that = this;
   
   $note.find(".glyphicon-chevron-up").click(function() { // find가 찾는게 클릭이벤트라
															// 객체를 디스로보는게 아니라
															// 체프론 업을 디스로 봄
      that.display();
   });
   $note.find(".glyphicon-pushpin").click(function() { // find가 찾는게 클릭이벤트라 객체를
														// 디스로보는게 아니라 체프론 업을 디스로
														// 봄
      that.fix();
   });
   $note.find(".glyphicon-trash").click(function() { // find가 찾는게 클릭이벤트라 객체를
														// 디스로보는게 아니라 체프론 업을 디스로
														// 봄
      that.del();
   });
};
// drag()
Memo.prototype.drag = function() {
   this.$note.draggable();
};
// display()
Memo.prototype.display = function() {
   if(!this.$note.hasClass("h20")){
      this.$note.toggleClass("h20");
      this.$note.find(".glyphicon-chevron-up").toggleClass("change");
   } else{
      this.$note.toggleClass("h20");
      this.$note.find(".glyphicon-chevron-up").toggleClass("change");
      
   }
};
// fix()
Memo.prototype.fix = function() {
   this.$note.find(".glyphicon-pushpin").toggleClass("choice");
   if(this.$note.find(".glyphicon-pushpin").hasClass("choice")){
      this.$note.draggable("disable");      
   } else{
      this.$note.draggable("enable");            
   }
};
// del()
Memo.prototype.del = function() {
   this.$note.remove();
};